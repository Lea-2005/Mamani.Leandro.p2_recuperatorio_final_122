package gestioncaza;

import Model.Almacenable;
import Model.Comparable.ComparatorModeloJet;
import Model.Inventario;
import Model.JetMilitar;
import Model.Tipojet;
import java.util.List;

public class GestionCaza {

    public static void main(String[] args) {
        
        try {
        Almacenable<JetMilitar> inv = new Inventario<>();
        
        inv.agregar(new JetMilitar(Tipojet.INTERCEPTOR, 1, "F-16C", 950.5, 60, 2014));
        inv.agregar(new JetMilitar(Tipojet.MULTIPROPOSITO, 2, "F-18E Super Hornet", 1200.2, 35, 2017));
        inv.agregar(new JetMilitar(Tipojet.INTERCEPTOR, 3, "Mirage 2000", 800.0, 25, 2010));
        inv.agregar(new JetMilitar(Tipojet.ATAQUE, 4, "A-10 Thunderbolt", 1400.7, 70, 2012));
        inv.agregar(new JetMilitar(Tipojet.ENTRENAMIENTO, 5, "T-38 Talon", 600.0, 50, 2018));
        inv.agregar(new JetMilitar(Tipojet.RECONOCIMIENTO, 6, "Gripen NG", 700.3, 15, 2010));
        
        
        System.out.println("=== Inventario original ===");
        for (JetMilitar j : inv.obtenerTodo()) {
            System.out.println(j);
        }
               
        // 1) Orden natural.
        System.out.println("\n=== Orden natural ===");
        inv.ordenar();
        for (JetMilitar j : inv.obtenerTodo()) {
            System.out.println(j);
        }
        
        // 2) Ordenar por modelo.
        System.out.println("\n=== Orden modelo ===");
        inv.ordenar(new ComparatorModeloJet());
        for (JetMilitar j : inv.obtenerTodo()) {
            System.out.println(j);
        }
        
        // 3) Filtrar jets con nivelCombustible < 20.
        List<JetMilitar> criticos = inv.filtrar(j -> j.getNivelCombustible() < 20);
        
        
        // 4) Transformar por ENTRENAMIENTO: +15% horasVuelo;
        List<JetMilitar> transformados = inv.transformar(j -> {
            if (j.getTipo() == Tipojet.ENTRENAMIENTO) {
                
                return new JetMilitar(
                        j.getTipo(), 
                        j.getId(), 
                        j.getModelo(), 
                        j.getHorasVuelo() * 1.15, 
                        j.getNivelCombustible(),
                        j.getAnioIngreso());
   
            }
        return j;
        });
        
        
        // 5) Contar ingresados antes de 2015.
        int antiguos = inv.contar(j -> j.getAnioIngreso() < 2015);
        
        // Persistencia.
        inv.guardarEnBinario("src/data/jets.bin");
        inv.guardarEnCSV("src/data/jets.csv");
        inv.guardarEnJSON("src/data/jets.json");
        
        // Cargar desde CSV.
        Almacenable<JetMilitar> invCSV = new Inventario<>();
        //invCSV.cargarDesdeCSV("src/data/jets.csv", JetMilitar::fromCSV);
        
        System.out.println("\n=== Inventario cargado desde CSV ===");        
        for (JetMilitar j : invCSV.obtenerTodo()) {
                System.out.println();
            }         
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

}
