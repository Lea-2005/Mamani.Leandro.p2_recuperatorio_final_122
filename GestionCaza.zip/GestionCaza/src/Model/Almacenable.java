package Model;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Almacenable<T> {
    
    void agregar(T elem);
    
    void eliminarSegun(Predicate<? super T> criterio);
    
    List<T> obtenerTodo();
    
    T buscar(Predicate<? super T> criterio);
    
    void ordenar();
    
    void ordenar(Comparator<? super T> comparador);
    
    List<T> filtrar(Predicate<? super T> criterio);
    
    List<T> transformar(Function<T, T> operador);
    
    int contar(Predicate<? super T> criterio);
    
    void guardarEnBinario(String ruta) throws Exception;
    
    List<T> cargarDesdeBinario(String ruta) throws Exception;
    
    void guardarEnCSV(String ruta) throws Exception;
    
    List<T> cargarDesdeCSV(String ruta, Function<T, T> fromCSV) throws Exception;
    
    void guardarEnJSON(String ruta) throws Exception;
}
