package Model;

import java.io.Serializable;

public abstract class AeronaveMilitar implements Serializable, Comparable<AeronaveMilitar>, CSVConvertible {

    private final int id;
    private final String modelo;
    private final double horasVuelo;
    private final int nivelCombustible;
    private final int anioIngreso;

    public AeronaveMilitar(int id, String modelo, double horasVuelo, int nivelCombustible, int anioIngreso) {
        this.id = id;
        this.modelo = modelo;
        this.horasVuelo = horasVuelo;
        this.nivelCombustible = nivelCombustible;
        this.anioIngreso = anioIngreso;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AeronaveMilitar other = (AeronaveMilitar) obj;
        return this.id == other.id;
    }

    public int getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public double getHorasVuelo() {
        return horasVuelo;
    }

    public int getNivelCombustible() {
        return nivelCombustible;
    }

    public int getAnioIngreso() {
        return anioIngreso;
    }

    @Override
    public String toCSV() {
        return id + "," + modelo + "," + horasVuelo + "," + nivelCombustible + "," + anioIngreso + "\n";
    }

    public static String toHeaderCSV() {
        return "id,modelo,horasVuelo,nivelCombustible,anioIngreso";
    }

    @Override
    public String toString() {
        return "AeronaveMilitar{" + "id=" + id + ", modelo=" + modelo + ", horasVuelo=" + horasVuelo + ", nivelCombustible=" + nivelCombustible + ", anioIngreso=" + anioIngreso + '}';
    }

}
