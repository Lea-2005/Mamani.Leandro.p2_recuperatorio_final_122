package Model.Comparable;

import Model.AeronaveMilitar;
import java.util.Comparator;

public class ComparatorModeloJet implements Comparator<AeronaveMilitar> {

    @Override
    public int compare(AeronaveMilitar a1, AeronaveMilitar a2) {
        return a1.getModelo().compareTo(a2.getModelo());
    }
    
}
