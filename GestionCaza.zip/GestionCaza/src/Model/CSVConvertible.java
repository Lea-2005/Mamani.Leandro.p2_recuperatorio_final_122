package Model;

public interface CSVConvertible {

    String toCSV(); 
    
}
