
package Model;

public class JetMilitar extends AeronaveMilitar {
    
    private final Tipojet tipo;

    public JetMilitar(Tipojet tipo, int id, String modelo, double horasVuelo, int nivelCombustible, int anioIngreso) {
        super(id, modelo, horasVuelo, nivelCombustible, anioIngreso);
        this.tipo = tipo;
    } 

    @Override
    public int compareTo(AeronaveMilitar a) {
        int cmp = Double.compare(a.getHorasVuelo(), this.getHorasVuelo());
        
        if (cmp == 0) {
            cmp = Integer.compare(a.getNivelCombustible(), this.getNivelCombustible());
        }       
        return cmp;
    }
    
    public JetMilitar fromCSV(String linea) {
        String[] datos = (linea.replace("\n", "").split(","));
        
        return new JetMilitar(
                Tipojet.valueOf(datos[0]),
                Integer.parseInt(datos[1]),
                datos[2],
                Double.parseDouble(datos[3]),
                Integer.parseInt(datos[4]),
                Integer.parseInt(datos[5])
                ) {};
    }

    public Tipojet getTipo() {
        return tipo;
    }

    
    
    
}
