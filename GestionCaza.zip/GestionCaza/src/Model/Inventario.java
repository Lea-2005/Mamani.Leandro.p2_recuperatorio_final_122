package Model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends AeronaveMilitar> implements Almacenable<T> {

    private List<T> listaElementos;

    public Inventario() {
        listaElementos = new ArrayList<>();
    }

    @Override
    public void agregar(T elem) {
        listaElementos.add(Objects.requireNonNull(elem));
    }

    @Override
    public void eliminarSegun(Predicate<? super T> criterio) {
        Iterator<T> it = listaElementos.iterator();

        for (T elem : listaElementos) {
            while (it.hasNext()) {
                if (criterio.test(it.next())) {
                    listaElementos.remove(elem);
                }
            }
        }
    }
   
    @Override
    public List<T> obtenerTodo() {
        return listaElementos;
    }

    @Override
    public T buscar(Predicate<? super T> criterio) {
        for (T elem : listaElementos) {
            if (criterio.test(elem)) {
                return elem;
            }
        }
        return null;
    }

    @Override
    public void ordenar() {
        listaElementos.sort(null);
    }

    @Override
    public void ordenar(Comparator<? super T> comparador) {
        listaElementos.sort(comparador); 
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        
        for (T elem : listaElementos) {
            if (criterio.test(elem)) {
                toReturn.add(elem);
            }
        }        
        return toReturn;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> toReturn = new ArrayList<>();
        
        for (T elem : listaElementos) {
            toReturn.add(operador.apply(elem));
        }
        return toReturn;
    }

    @Override
    public int contar(Predicate<? super T> criterio) {
        int contador = 0;
        
        for (T elem : listaElementos) {
            if (criterio.test(elem)) {
                contador++;
            }
        }
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        validarCarpeta(ruta);
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(ruta))) {
            output.writeObject(listaElementos);
        }
    }
    
    @Override
    public List<T> cargarDesdeBinario(String ruta) throws Exception {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(ruta))) {
            return listaElementos = (List<T>) input.readObject();
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        validarCarpeta(ruta);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            bw.write(AeronaveMilitar.toHeaderCSV());
            
            for (T elem : listaElementos) {
                bw.write(elem.toCSV());
            }            
        }
    }

    @Override
    public List<T> cargarDesdeCSV(String ruta, Function<T, T> fromCSV) throws Exception {  
        List<T> toReturn = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            br.readLine();
            
            for (T elem : listaElementos) {
                toReturn.add(fromCSV.apply(elem));
            }
        }
        return toReturn;
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        validarCarpeta(ruta);
        //
    }
    
    private void validarCarpeta(String ruta) {
        File archivo = new File(ruta);
        File carpeta = archivo.getParentFile();
        
        if (carpeta != null && !carpeta.exists()) {
            carpeta.mkdirs();
        }
    }
}
